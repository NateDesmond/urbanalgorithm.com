import mlx_whisper, json, sys, glob, re
L=json.load(open("lines.json"))
norm=lambda s: re.sub(r"[^a-z0-9 ]","",s.lower().replace("600","six hundred")).split()
bad=0
for k in (sys.argv[1:] or L):
    r=mlx_whisper.transcribe(f"vo/{k}.wav", path_or_hf_repo="mlx-community/whisper-small.en-mlx", word_timestamps=True)
    got=r["text"].strip(); ok = norm(got)[-1:]==norm(L[k])[-1:] and abs(len(norm(got))-len(norm(L[k])))<=1
    bad+= not ok
    print(f"{k:4s} {'OK ' if ok else 'BAD'} {got}")
    json.dump([w for s in r["segments"] for w in s["words"]], open(f"vo/{k}.words.json","w"))
print("bad:",bad)

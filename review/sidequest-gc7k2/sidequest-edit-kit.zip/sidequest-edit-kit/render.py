"""Render a polished intro from a beat script.
Usage: python3 render.py A|B|C [--preview]
Footage: ../hq.mp4 (his upload, 1080p). VO: vo/<key>.wav (Chirp3-HD Puck). SFX: Urban Algorithm-owned set."""
import json, math, subprocess, sys, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H, FPS = 1920, 1080, 30
SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "source.mp4")  # your original 1080p export
SFX = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sfx", "sfx-%s.mp3")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
os.makedirs(OUT, exist_ok=True); os.makedirs("build", exist_ok=True)

# ---- brand ----
NAVY = (24, 33, 42); ORANGE = (240, 160, 58); BURNT = (226, 112, 44); CREAM = (242, 232, 216)
RED = (232, 72, 72)
DIN = "/System/Library/Fonts/Supplemental/DIN Condensed Bold.ttf"
AV = "/System/Library/Fonts/Supplemental/Avenir Next Condensed.ttc"
_fc = {}
def font(path, size, idx=0):
    k = (path, size, idx)
    if k not in _fc: _fc[k] = ImageFont.truetype(path, size, index=idx)
    return _fc[k]
LOGO = Image.open("logo.png")

# ---- timing helpers ----
L = json.load(open("lines.json"))
def vo_dur(k):
    return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f"vo/{k}.wav"]))
def word_at(k, sub):
    sub, _, nth = sub.partition("@"); nth = int(nth or 1)
    for w in json.load(open(f"vo/{k}.words.json")):
        if sub.lower() in w["word"].lower():
            nth -= 1
            if nth == 0: return w["start"]
    raise KeyError(f"{sub!r} not in {k}")

clamp = lambda x: max(0.0, min(1.0, x))
def out_back(x, s=1.9):
    x = clamp(x) - 1; return 1 + (s + 1) * x ** 3 + s * x ** 2
def out_cubic(x): return 1 - (1 - clamp(x)) ** 3

# ---- graphics (each draws onto an RGBA layer at time t) ----
def paste_scaled(layer, img, cx, cy, scale, alpha=1.0, rot=0):
    if scale <= 0.01 or alpha <= 0.01: return
    im = img.rotate(rot, resample=Image.BICUBIC, expand=True) if rot else img
    w, h = max(1, int(im.width * scale)), max(1, int(im.height * scale))
    im = im.resize((w, h), Image.LANCZOS)
    if alpha < 1:
        a = im.getchannel("A").point(lambda v: int(v * alpha)); im.putalpha(a)
    layer.alpha_composite(im, (int(cx - w / 2), int(cy - h / 2)))

def shadowed(img, blur=14, off=(0, 8), opacity=150):
    pad = blur * 3
    out = Image.new("RGBA", (img.width + pad * 2, img.height + pad * 2), (0, 0, 0, 0))
    sh = Image.new("RGBA", img.size, (0, 0, 0, 0)); sh.putalpha(img.getchannel("A").point(lambda v: v * opacity // 255))
    out.alpha_composite(sh, (pad + off[0], pad + off[1])); out = out.filter(ImageFilter.GaussianBlur(blur))
    out.alpha_composite(img, (pad, pad)); return out

_cache = {}
def tag_img(text):
    if ("tag", text) in _cache: return _cache[("tag", text)]
    f = font(DIN, 170); tw = int(f.getlength(text)); w, h = tw + 150, 200
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.polygon([(0, h / 2), (60, 0), (w, 0), (w, h), (60, h)], fill=ORANGE)
    d.rounded_rectangle([50, 0, w, h], 22, fill=ORANGE)
    d.ellipse([34, h / 2 - 15, 64, h / 2 + 15], fill=NAVY)
    d.text((95, h / 2 + 12), text, font=f, fill=NAVY, anchor="lm")
    _cache[("tag", text)] = shadowed(im); return _cache[("tag", text)]

def g_price(layer, t, a, b, text="$600", pos=(1460, 300)):
    if not a <= t < b: return
    p = (t - a) / 0.32; e = clamp((b - t) / 0.22)
    paste_scaled(layer, tag_img(text), pos[0], pos[1], out_back(p) * (0.85 + 0.15 * e), e, rot=7)

def punch_img(text, fill, stroke):
    k = ("punch", text, fill)
    if k in _cache: return _cache[k]
    f = font(DIN, 150); tw = int(f.getlength(text)) + 60
    im = Image.new("RGBA", (tw, 210), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.text((tw / 2, 120), text, font=f, fill=fill, anchor="mm", stroke_width=9, stroke_fill=stroke)
    _cache[k] = shadowed(im, 12, (0, 6), 170); return _cache[k]

def g_punch(layer, t, a, b, text, color="white", pos=(960, 860)):
    if not a <= t < b: return
    fill = {"white": (255, 255, 255), "red": RED, "orange": ORANGE}[color]
    p = clamp((t - a) / 0.16); e = clamp((b - t) / 0.15)
    paste_scaled(layer, punch_img(text, fill, (12, 14, 18)), pos[0], pos[1], 1.25 - 0.25 * out_cubic(p), min(p * 1.5, 1) * e)

def stamp_img(text, color):
    k = ("stamp", text, color)
    if k in _cache: return _cache[k]
    f = font(DIN, 150); tw = int(f.getlength(text))
    im = Image.new("RGBA", (tw + 90, 200), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([8, 8, im.width - 9, 191], 18, outline=color, width=12)
    d.text((im.width / 2, 112), text, font=f, fill=color, anchor="mm")
    _cache[k] = shadowed(im, 10, (0, 6), 170); return _cache[k]

def g_stamp(layer, t, a, b, text, color="red", pos=(960, 540), rot=-10):
    if not a <= t < b: return
    c = {"red": RED, "orange": ORANGE, "white": (255, 255, 255)}[color]
    p = clamp((t - a) / 0.12); e = clamp((b - t) / 0.15)
    paste_scaled(layer, stamp_img(text, c), pos[0], pos[1], 1.9 - 0.9 * p, min(1, p * 2) * e, rot=rot)

def chip_img(text, bg, fg, size=44):
    k = ("chip", text, bg, fg, size)
    if k in _cache: return _cache[k]
    f = font(AV, size, 8); tw = int(f.getlength(text))
    im = Image.new("RGBA", (tw + 48, size + 30), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, im.width - 1, im.height - 1], 10, fill=bg)
    d.text((24, im.height / 2 + 2), text, font=f, fill=fg, anchor="lm")
    _cache[k] = shadowed(im, 10, (0, 5), 140); return _cache[k]

def g_chip(layer, t, a, b, text, x, y, style="navy", anchor="l"):
    if not a <= t < b: return
    bg, fg = {"navy": (NAVY + (235,), CREAM), "orange": (ORANGE + (255,), NAVY)}[style]
    im = chip_img(text, bg, fg)
    p = out_cubic((t - a) / 0.22); e = clamp((b - t) / 0.18)
    cx = (x + im.width / 2 if anchor == "l" else x - im.width / 2) + (1 - p) * (-40 if anchor == "l" else 40)
    paste_scaled(layer, im, cx, y, 1, p * e)

def g_flash(layer, t, a, dur=0.22):
    if a <= t < a + dur:
        al = int(225 * (1 - (t - a) / dur) ** 2)
        layer.alpha_composite(Image.new("RGBA", (W, H), (255, 250, 240, al)))

def g_ticker(layer, t, a, value="$600"):
    if t < a: return
    k = ("ticker", value)
    if k not in _cache:
        f1, f2 = font(AV, 30, 2), font(DIN, 76)
        im = Image.new("RGBA", (300, 112), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
        d.rounded_rectangle([0, 0, 299, 111], 18, fill=NAVY + (235,))
        d.rounded_rectangle([0, 0, 14, 111], 7, fill=ORANGE)
        d.text((40, 32), "SPENT SO FAR", font=f1, fill=ORANGE, anchor="lm")
        d.text((38, 84), value, font=f2, fill=CREAM, anchor="lm")
        _cache[k] = shadowed(im, 12, (0, 6), 150)
    im = _cache[k]; p = out_back((t - a) / 0.35, 1.4)
    paste_scaled(layer, im, W - 70 - im.width / 2 + (1 - p) * 360 + 40, 70 + im.height / 2 - 40, 1, clamp(p * 2))

def g_chapter(layer, t, a, b, num, title):
    if not a <= t < b: return
    p = out_cubic((t - a) / 0.35); e = clamp((b - t) / 0.25)
    band_w = int(1100 * p); y = 790
    if band_w > 4:
        band = Image.new("RGBA", (band_w, 170), NAVY + (int(225 * e),))
        layer.alpha_composite(band, (0, y))
        layer.alpha_composite(Image.new("RGBA", (12, 170), ORANGE + (int(255 * e),)), (max(0, band_w - 12), y))
    tp = clamp((t - a - 0.12) / 0.3)
    if tp > 0:
        ti = Image.new("RGBA", (1000, 170), (0, 0, 0, 0)); d = ImageDraw.Draw(ti)
        d.text((90, 52), num, font=font(AV, 40, 8), fill=ORANGE, anchor="lm")
        d.text((88, 128), title, font=font(DIN, 110), fill=CREAM, anchor="lm")
        ti.putalpha(ti.getchannel("A").point(lambda v: int(v * out_cubic(tp) * e)))
        layer.alpha_composite(ti, (int(-30 * (1 - out_cubic(tp))), y))
        if band_w > 300:
            lg = LOGO.resize((96, 93), Image.LANCZOS); lg.putalpha(lg.getchannel("A").point(lambda v: int(v * tp * e)))
            layer.alpha_composite(lg, (band_w - 96 - 50, y + 38))

class QuestLog:
    """Plain to-do checkboxes, top-left. Each lands on the spoken word."""
    X, Y, ROW = 78, 84, 78
    def __init__(self): self.open = None; self.close = None; self.items = []
    def row(self, label, kind):
        k = ("cb", label, kind)
        if k not in _cache:
            col = ORANGE if kind == "ask" else (255, 255, 255)
            f = font(DIN, 64); tw = int(f.getlength(label))
            im = Image.new("RGBA", (tw + 110, 76), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
            d.rounded_rectangle([6, 12, 58, 64], 8, outline=(12, 14, 18), width=11)
            d.rounded_rectangle([6, 12, 58, 64], 8, outline=col, width=6)
            d.text((84, 44), label, font=f, fill=col, anchor="lm", stroke_width=4, stroke_fill=(12, 14, 18))
            _cache[k] = shadowed(im, 10, (0, 4), 160)
        return _cache[k]
    def draw(self, layer, t):
        if self.open is None or t < self.open: return
        if self.close is not None and t >= self.close + 0.3: return
        fade = 1 if self.close is None or t < self.close else 1 - out_cubic((t - self.close) / 0.3)
        y = self.Y
        for (ta, label, status, kind) in self.items:
            if t < ta: break
            q = out_cubic((t - ta) / 0.2)
            sc = 1 + 0.25 * (1 - out_back((t - ta) / 0.3, 2.2))
            if kind == "ask": sc *= 1 + 0.04 * math.sin((t - ta) * 6)
            im = self.row(label, kind)
            paste_scaled(layer, im, self.X + im.width / 2 - 30 - 40 * (1 - q), y + 38, sc, q * fade)
            y += self.ROW

# ---- footage ----
def grade(fr, kind):
    if not kind: return fr
    f = fr.astype(np.float32)
    lum = f @ np.array([0.299, 0.587, 0.114], np.float32)
    if kind == "before":
        f = lum[..., None] + (f - lum[..., None]) * 0.78; f = (f - 128) * 0.96 + 124; f *= np.array([0.97, 1.0, 1.04], np.float32)
    elif kind == "after":
        f = lum[..., None] + (f - lum[..., None]) * 1.18; f = (f - 128) * 1.06 + 130; f *= np.array([1.04, 1.0, 0.95], np.float32)
    elif kind == "dark":
        f = lum[..., None] + (f - lum[..., None]) * 0.6; f = f * 0.62 * VIG[..., None]
    return np.clip(f, 0, 255).astype(np.uint8)
yy, xx = np.mgrid[0:H, 0:W]
VIG = np.clip(1.25 - 0.85 * (((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2) ** 0.5, 0.25, 1).astype(np.float32)

def read_frames(src, n, speed=1.0, w=W, h=H):
    cmd = ["ffmpeg", "-loglevel", "error", "-ss", f"{src:.3f}", "-i", SRC, "-t", f"{n / FPS * speed + 0.5:.3f}",
           "-vf", f"setpts=PTS/{speed},fps={FPS},scale={w}:{h}:flags=lanczos", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
    raw = subprocess.run(cmd, capture_output=True, check=True).stdout
    fr = np.frombuffer(raw, np.uint8).reshape(-1, h, w, 3)
    if len(fr) < n: fr = np.concatenate([fr, np.repeat(fr[-1:], n - len(fr), 0)])
    return fr[:n]

def zoom(fr, z, cx=0.5, cy=0.5):
    if abs(z - 1) < 1e-4: return fr
    im = Image.fromarray(fr); cw, ch = W / z, H / z
    x0 = (W - cw) * cx; y0 = (H - ch) * cy
    return np.asarray(im.transform((W, H), Image.AFFINE, (1 / z, 0, x0, 0, 1 / z, y0), Image.BICUBIC))

def shot_frames(sh, n):
    if "split" in sh:
        a, b = sh["split"]; sp = sh.get("speed", 1.0)
        fa = read_frames(a, n, sp)[:, :, 480:1440]
        fb = read_frames(b, n, sp)[:, :, 480:1440]
        fr = np.concatenate([grade(fa, "before"), grade(fb, "after")], axis=2)
        fr[:, :, 956:964] = CREAM
        return fr
    fr = read_frames(sh["src"], n, sh.get("speed", 1.0))
    z0, z1 = sh.get("zoom", (1.0, 1.05)); cx, cy = sh.get("focus", (0.5, 0.5))
    kicks = sh.get("_kicks", []); shakes = list(kicks) + ([0.0] if sh.get("shake") else [])
    rng = np.random.default_rng(7)
    out = np.empty_like(fr)
    for i in range(n):
        ts = i / FPS
        z = z0 + (z1 - z0) * (i / max(1, n - 1))
        for k in kicks:  # punch-in: +13% over 3 frames, then holds
            z *= 1 + 0.13 * clamp((ts - k) * FPS / 3)
        ox = oy = 0.0
        for k in shakes:
            if 0 <= ts - k < 0.22:
                amp = 0.14 * (1 - (ts - k) / 0.22); ox += rng.uniform(-amp, amp); oy += rng.uniform(-amp, amp)
        if ox or oy: z = max(z, 1.04)
        out[i] = grade(zoom(fr[i], z, clamp(cx + ox), clamp(cy + oy)), sh.get("grade"))
    return out

# ---- build ----
def build(spec, name, preview=False):
    beats = spec["beats"]; t = 0.0; timeline = []; vo_events = []; sfx_events = []; gfx = []
    ql = QuestLog(); music_modes = []; starts = []
    for bt in beats:
        starts.append(t)
        d = vo_dur(bt["vo"]) if bt.get("vo") else 0
        lead = bt.get("lead", 0.12) if bt.get("vo") else 0
        dur = max(bt.get("min", 0), lead + d + bt.get("pad", 0.22))
        if bt.get("cut_at"): dur = lead + word_at(bt["vo"], bt["cut_at"])
        if bt.get("vo"): vo_events.append((bt["vo"], t + lead))
        # shots: fixed-duration ones first, the rest share what's left
        fixed = sum(s.get("dur", 0) for s in bt["shots"]); free = [s for s in bt["shots"] if "dur" not in s]
        dur = max(dur, fixed + 0.4 * len(free)); share = (dur - fixed) / len(free) if free else 0
        if not free: dur = fixed
        st = t
        W0 = lambda sub, k=bt.get("vo"), base=t + lead: base + word_at(k, sub)
        for s in bt["shots"]:
            sd = s.get("dur", share); s = dict(s)
            s["_kicks"] = [((t + x) if isinstance(x, (int, float)) else W0(x)) - st for x in s.get("kicks", [])]
            timeline.append((s, st, sd)); st += sd
        W_ = lambda sub, k=bt.get("vo"), base=t + lead: base + word_at(k, sub)
        for ev in bt.get("events", []):
            kind, args = ev[0], ev[1:]
            at = lambda x: t + x if isinstance(x, (int, float)) else (t + dur if x == "beat" else W_(x))
            if kind == "sfx": sfx_events.append((args[0], at(args[1]), args[2] if len(args) > 2 else 0))
            elif kind == "ql_open": ql.open = at(args[0])
            elif kind == "ql_close": ql.close = at(args[0])
            elif kind == "ql_add": ql.items.append((at(args[0]), args[1], args[2], args[3]))
            elif kind == "music": music_modes.append((at(args[0]), args[1]))
            else: gfx.append((kind, at(args[0]), at(args[1]) if len(args) > 1 else None, args))
        t += dur
    total = t
    print(f"{name}: {total:.2f}s, {len(timeline)} shots", flush=True)

    # video: footage + graphics, piped straight into the encoder
    nframes = int(round(total * FPS))
    vout = f"build/{name}_v.mp4"
    enc = subprocess.Popen(["ffmpeg", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                            "-c:v", "libx264", "-preset", "veryfast" if preview else "slow", "-crf", "16", "-pix_fmt", "yuv420p", vout], stdin=subprocess.PIPE)
    fi = 0
    for (s, st, sd) in timeline:
        n = int(round((st + sd) * FPS)) - int(round(st * FPS))
        frames = shot_frames(s, n)
        for k in range(n):
            tt = (fi) / FPS
            layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            for (kind, a, b, args) in gfx:
                if kind == "price": g_price(layer, tt, a, b, *args[2:])
                elif kind == "punch": g_punch(layer, tt, a, b, *args[2:])
                elif kind == "chip": g_chip(layer, tt, a, b, *args[2:])
                elif kind == "stamp": g_stamp(layer, tt, a, b, *args[2:])
                elif kind == "flash": g_flash(layer, tt, a)
                elif kind == "ticker": g_ticker(layer, tt, a)
                elif kind == "chapter": g_chapter(layer, tt, a, b, *args[2:])
            ql.draw(layer, tt)
            base = Image.fromarray(frames[k]).convert("RGBA"); base.alpha_composite(layer)
            enc.stdin.write(base.convert("RGB").tobytes()); fi += 1
    enc.stdin.close(); enc.wait()

    # audio: VO bus, SFX bus, music bed (his own track) ducked under VO, two-pass loudnorm
    HIT = 68.07  # a strong downbeat in his montage track; lands exactly on the drop cut
    m_off = HIT - starts[spec["drop_beat"]] if "drop_beat" in spec else spec["music_offset"]
    inputs = ["-ss", f"{m_off:.3f}", "-t", f"{total + 0.5:.3f}", "-i", SRC]
    fc = []; vo_labels = []; sfx_labels = []; idx = 1
    for (k, at) in vo_events:
        inputs += ["-i", f"vo/{k}.wav"]; fc.append(f"[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,adelay={int(at * 1000)}:all=1[v{idx}]"); vo_labels.append(f"[v{idx}]"); idx += 1
    for (nm, at, gain) in sfx_events:
        inputs += ["-i", SFX % nm]; fc.append(f"[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,volume={gain}dB,adelay={int(max(0, at) * 1000)}:all=1[s{idx}]"); sfx_labels.append(f"[s{idx}]"); idx += 1
    fc.append(f"{''.join(vo_labels)}amix=inputs={len(vo_labels)}:normalize=0,highpass=f=90,equalizer=f=1000:t=q:w=1.2:g=-3,equalizer=f=2600:t=q:w=1:g=-1.5,lowshelf=f=170:g=2.5,acompressor=threshold=-20dB:ratio=3:attack=5:release=120:makeup=2,asplit[vo][key]")
    # music modes: piecewise full / muffled / off, switched on the events
    modes = sorted(music_modes) or [(0, "full")]
    def expr(want):
        e = "0"
        for (a, m) in reversed(modes): e = f"if(gte(t,{a:.3f}),{1 if m == want else 0},{e})"
        return e
    fc.append(f"[0:a]aresample=48000,asplit[mf][mm]")
    fc.append(f"[mf]volume='{expr('full')}':eval=frame,volume=-7dB[mfull]")
    fc.append(f"[mm]lowpass=f=500,lowpass=f=500,volume='{expr('muffled')}':eval=frame,volume=-6dB[mmuf]")
    fc.append(f"[mfull][mmuf]amix=inputs=2:normalize=0,afade=t=out:st={total - 0.6:.3f}:d=0.6[bed]")
    fc.append(f"[bed][key]sidechaincompress=threshold=0.025:ratio=7:attack=15:release=350[duck]")
    mix_in = "[duck][vo]" + "".join(sfx_labels)
    fc.append(f"{mix_in}amix=inputs={2 + len(sfx_labels)}:normalize=0,atrim=0:{total:.3f}[mix]")
    araw = f"build/{name}_a.wav"
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", *inputs, "-filter_complex", ";".join(fc), "-map", "[mix]", "-ar", "48000", araw], check=True)
    meas = subprocess.run(["ffmpeg", "-hide_banner", "-i", araw, "-af", "loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"], capture_output=True, text=True).stderr
    m = json.loads(meas[meas.rindex("{"):meas.rindex("}") + 1])
    ln = (f"loudnorm=I=-14:TP=-1.5:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}"
          f":measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true")
    final = f"{OUT}/{spec['file']}.mp4"
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", vout, "-i", araw, "-af", ln, "-ar", "48000", "-c:v", "copy", "-c:a", "aac", "-b:a", "320k",
                    "-movflags", "+faststart", "-shortest", final], check=True)
    json.dump({"total": total, "vo": vo_events, "shots": [(s.get("src", s.get("split")), round(st, 2), round(sd, 2)) for s, st, sd in timeline]},
              open(f"build/{name}_plan.json", "w"), indent=1)
    print("wrote", final)

if __name__ == "__main__":
    from specs import SPECS
    for n in sys.argv[1:]:
        if n.startswith("--"): continue
        build(SPECS[n], n, "--preview" in sys.argv)

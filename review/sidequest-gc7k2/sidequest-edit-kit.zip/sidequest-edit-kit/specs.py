# v4: research-backed scripts (research/FINAL_INTROS_v2.md). Event times: number = s from beat start,
# "word" / "word@2" = when spoken, "beat" = beat end. Shot "kicks" = punch-in + shake on that word.
BEFORE, AFTER = "before", "after"
NEW_CHIP = ("NEW ≈ $10,000", 1730, 450, "navy", "r")
ROOF = dict(src=90.6, zoom=(1.0, 1.05))
STEP1 = [("ql_close", 0), ("sfx", "whoosh", -0.2, -8), ("chapter", 0.15, "beat", "STEP 1", "TEAR IT DOWN"),
         ("sfx", "sectiontitle", 0.15, -8), ("ticker", 0.8), ("sfx", "cash", 0.8, -12)]
def add(word, label, kind="bad", sfx="pop"):
    return [("ql_add", word, label, "", kind), ("sfx", sfx if kind == "bad" else "stamp", word, -10 if kind == "bad" else -8)]
import json as _j
_w = _j.load(open("vo/P1.words.json"))
_at = lambda sub: next(w["start"] for w in _w if sub in w["word"])
P1_TEN = _at("$10") - _at(" or")  # "$10,000" lands inside the beat after the cut
END = dict(min=2.7, shots=[ROOF], events=STEP1)

# 1 · THE BET
P = dict(file="1_the_bet", drop_beat=1, beats=[
  dict(vo="P1", lead=0.03, cut_at="or", shots=[dict(src=127.6, zoom=(1.15, 1.25), kicks=["wasted"])], events=[
      ("music", 0, "muffled"), ("price", "600", "beat"), ("sfx", "stamp", "600", -6)]),
  dict(min=2.6, shots=[dict(src=560.2, grade=AFTER, zoom=(1.08, 1.0), shake=True)], events=[
      ("music", 0, "full"), ("flash", 0), ("sfx", "impact", 0, -2), ("sfx", "whoosh", -0.15, -8),
      ("chip", P1_TEN, "beat", *NEW_CHIP), ("sfx", "cash", P1_TEN, -9)]),
  dict(vo="P2", lead=0.08, pad=0.1, shots=[dict(src=0.4, speed=1.3, grade=BEFORE, zoom=(1.0, 1.06), kicks=["lit"])], events=[
      ("stamp", "lit", "beat", "DEAD", "red", (1380, 380), -10), ("sfx", "stamp", "lit", -4), ("sfx", "whoosh2", -0.12, -10)]),
  dict(vo="P3", lead=0.03, pad=0.08, shots=[dict(src=49.0, dur=1.3, grade=BEFORE), dict(src=6.4, dur=1.2, grade=BEFORE, zoom=(1.04, 1.12)),
      dict(src=17.1, dur=0.9, grade=BEFORE, zoom=(1.05, 1.1)), dict(src=13.0, grade=BEFORE, zoom=(1.02, 1.1))], events=[
      ("ql_open", "Battery"), *add("Battery", "BATTERIES"), *add("solenoid", "SOLENOID"), *add("Controller", "CONTROLLER")]),
  dict(vo="P4", lead=0.03, pad=0.08, shots=[dict(src=21.6, dur=0.9, grade=BEFORE, zoom=(1.0, 1.08)), dict(src=44.3, dur=1.0, grade=BEFORE, zoom=(1.06, 1.12)),
      dict(src=332.0, grade=BEFORE, zoom=(1.0, 1.08))], events=[*add("Chalky", "BODY")]),
  dict(vo="P5", lead=0.03, pad=0.12, shots=[dict(src=250.5, zoom=(1.0, 1.08), kicks=["painting"])], events=[
      ("stamp", "not", "beat", "NO REPAINT", "orange", (1320, 430), -8), ("sfx", "stamp", "not", -6)]),
  dict(vo="P6", lead=0.05, pad=0.1, shots=[dict(src=503.5, dur=1.3, zoom=(1.0, 1.08)), dict(src=517.3, grade=AFTER, zoom=(1.0, 1.1), kicks=["drives"])], events=[
      ("music", 0, "muffled"), *add("drives", "MAKE IT DRIVE", "ask")]),
  dict(vo="P7", lead=0.05, pad=0.15, shots=[dict(src=571.6, grade=AFTER, zoom=(1.0, 1.08), kicks=["lawn"])], events=[("music", 0, "full")]),
  END,
])

# 2 · THE LIST
L = dict(file="2_the_list", drop_beat=1, beats=[
  dict(vo="L1", lead=0.03, pad=0.05, shots=[dict(src=0.4, speed=1.3, grade=BEFORE, zoom=(1.0, 1.05), kicks=["turn"])], events=[
      ("music", 0, "muffled"), ("price", "$600", "beat"), ("sfx", "stamp", "$600", -6),
      ("stamp", "turn", "beat", "DEAD", "red", (1380, 560), -10), ("sfx", "stamp", "turn", -4)]),
  dict(vo="L2", lead=0.12, pad=0.15, shots=[dict(src=571.6, grade=AFTER, zoom=(1.1, 1.0), shake=True)], events=[
      ("music", 0, "full"), ("flash", 0), ("sfx", "impact", 0, -2), ("chip", "10", "beat", *NEW_CHIP), ("sfx", "cash", "10", -9)]),
  dict(vo="L3", lead=0.03, pad=0.08, shots=[dict(src=49.5, speed=1.2, grade=BEFORE, zoom=(1.0, 1.06), kicks=["reason"])], events=[("sfx", "whoosh2", -0.12, -10)]),
  dict(vo="L4", lead=0.03, pad=0.08, shots=[dict(src=6.4, grade=BEFORE, zoom=(1.0, 1.12), kicks=["Batteries"])], events=[
      ("ql_open", "Batteries"), *add("Batteries", "BATTERIES")]),
  dict(vo="L5", lead=0.03, pad=0.08, shots=[dict(src=17.1, dur=1.3, grade=BEFORE, zoom=(1.05, 1.12)), dict(src=13.0, grade=BEFORE, zoom=(1.02, 1.12))], events=[
      *add("Solenoid", "SOLENOID"), *add("Controller", "CONTROLLER")]),
  dict(vo="L6", lead=0.03, pad=0.08, shots=[dict(src=138.5, zoom=(1.0, 1.1))]),
  dict(vo="L7", lead=0.03, pad=0.1, shots=[dict(src=31.5, dur=1.4, grade=BEFORE, zoom=(1.0, 1.08)), dict(src=44.3, dur=1.0, grade=BEFORE, zoom=(1.06, 1.12)), dict(src=250.5, zoom=(1.0, 1.08))], events=[
      *add("body", "BODY"), ("stamp", "repainting", "beat", "NO REPAINT", "orange", (1320, 430), -8), ("sfx", "stamp", "repainting", -6)]),
  dict(vo="L8", lead=0.05, pad=0.1, shots=[dict(src=142.5, dur=2.0, zoom=(1.0, 1.06)), dict(src=503.5, zoom=(1.0, 1.08))], events=[
      ("music", 0, "muffled"), *add("last", "MAKE IT DRIVE", "ask")]),
  dict(vo="L9", lead=0.05, pad=0.3, shots=[dict(src=560.2, grade=AFTER, zoom=(1.0, 1.06), kicks=["move"])], events=[("music", 0, "full"), ("sfx", "whoosh", -0.15, -9)]),
  END,
])

# 3 · FROM THIS
F = dict(file="3_from_this", music_offset=68.07, beats=[
  dict(vo="F1", lead=0.03, pad=0.1, shots=[dict(src=571.6, grade=AFTER, zoom=(1.1, 1.0), shake=True)], events=[
      ("music", 0, "full"), ("flash", 0), ("sfx", "impact", 0, -2), ("price", "$600", "beat"), ("sfx", "stamp", "$600", -6)]),
  dict(vo="F2", lead=0.03, pad=0.1, shots=[dict(src=574.2, grade=AFTER, zoom=(1.0, 1.07))], events=[
      ("chip", "10", "beat", *NEW_CHIP), ("sfx", "cash", "10", -9)]),
  dict(vo="F3", lead=0.03, pad=0.08, shots=[dict(src=0.4, dur=2.3, speed=1.3, grade=BEFORE, zoom=(1.0, 1.05)), dict(src=6.4, grade=BEFORE, zoom=(1.02, 1.12), kicks=["turn"])], events=[
      ("sfx", "whoosh2", -0.12, -10), ("stamp", "turn", "beat", "DEAD", "red", (1380, 380), -10), ("sfx", "stamp", "turn", -4)]),
  dict(vo="F4", lead=0.03, pad=0.08, shots=[dict(src=8.4, dur=0.8, grade=BEFORE, zoom=(1.05, 1.12)), dict(src=17.1, dur=0.8, grade=BEFORE, zoom=(1.06, 1.12)), dict(src=13.0, grade=BEFORE, zoom=(1.02, 1.12))], events=[
      ("ql_open", "batt"), *add("batt", "BATTERIES"), *add("sole", "SOLENOID"), *add("contr", "CONTROLLER")]),
  dict(vo="F5", lead=0.03, pad=0.08, shots=[dict(src=44.3, dur=1.3, grade=BEFORE, zoom=(1.06, 1.12)), dict(src=21.6, grade=BEFORE, zoom=(1.0, 1.08))], events=[*add("plastic", "BODY")]),
  dict(vo="F6", lead=0.03, pad=0.1, shots=[dict(src=31.5, dur=2.4, grade=BEFORE, zoom=(1.0, 1.06), kicks=["not"]), dict(src=250.5, zoom=(1.0, 1.08))], events=[
      ("stamp", "buffer", "beat", "NO REPAINT", "orange", (1320, 430), -8), ("sfx", "stamp", "buffer", -6)]),
  dict(vo="F7", lead=0.03, pad=0.15, shots=[dict(src=338.6, zoom=(1.12, 1.22), kicks=["black"])]),
  dict(vo="F8", lead=0.05, pad=0.1, shots=[dict(src=503.5, zoom=(1.0, 1.1))], events=[("music", 0, "muffled")]),
  dict(vo="F9", lead=0.05, pad=0.2, shots=[dict(src=517.3, dur=1.6, grade=AFTER, zoom=(1.0, 1.08)), dict(src=562.8, grade=AFTER, zoom=(1.0, 1.1), kicks=["chair"])], events=[
      *add("drives", "MAKE IT DRIVE", "ask"), ("music", "Worst", "full")]),
  END,
])
SPECS = {"1": P, "2": L, "3": F}

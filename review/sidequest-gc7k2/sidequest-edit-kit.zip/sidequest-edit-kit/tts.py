import json, sys, base64, urllib.request, re, os
KEY = os.environ.get("GOOGLE_TTS_KEY", "")  # a Google Cloud API key with Text-to-Speech enabled
def tts(text, voice, out, rate=1.0):
    body = {"input": {"text": text}, "voice": {"languageCode": "en-US", "name": voice},
            "audioConfig": {"audioEncoding": "LINEAR16", "sampleRateHertz": 48000, "speakingRate": rate}}
    req = urllib.request.Request("https://texttospeech.googleapis.com/v1/text:synthesize?key=" + KEY,
        data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    open(out, "wb").write(base64.b64decode(json.load(urllib.request.urlopen(req))["audioContent"]))
if __name__ == "__main__":
    line = "This is my 2012 Yamaha G29. And as nice as it looks on the outside, there are a few major problems. The batteries are all gone."
    for v in sys.argv[1:]:
        tts(line, f"en-US-Chirp3-HD-{v}", f"voices/{v}.wav"); print(v)

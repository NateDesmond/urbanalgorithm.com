# Sidequest edit kit: "$600 golf cart"

Everything used to build the three new intros, so you (or Claude Code) can change a line or a cut and re-render.

## What's here
- `scripts/FINAL_INTROS_v2.md`: the three intro scripts with shot timecodes.
- `scripts/BODY_TALK_TRACK.md`: the full talk track for the rest of the video (steps 1-6), with timecodes into your original footage.
- `scripts/PLAYBOOK.md`: research on how the biggest build/restoration channels open their videos (44 breakout videos), plus the scoring rubric.
- `scripts/FACTS.md`: what we can and can't say on camera.
- `render.py` + `specs.py`: the renderer. Each intro is a list of beats (voice line, shots by timecode, graphics, sound effects).
- `lines.json` + `vo/`: the AI voice lines (Google Chirp3-HD "Puck"). Re-record your own and drop them in with the same file names.
- `sfx/`, `logo.png`: sound effects and your logo.

## Run it
1. Put your original 1080p export next to `render.py` as `source.mp4`.
2. `pip install pillow numpy` (ffmpeg must be installed).
3. `python3 render.py 1 2 3` writes `out/1_the_bet.mp4`, `out/2_the_list.mp4`, `out/3_from_this.mp4`. Add `--preview` for a fast draft.

To change a voice line: edit `lines.json`, set `GOOGLE_TTS_KEY`, run `python3 -c "..."` (see tts.py) or record it yourself as `vo/<KEY>.wav`. Word timings for graphics come from `vo/<KEY>.words.json` (Whisper); if you re-record, regenerate them with `stt.py` (needs `pip install mlx-whisper` on a Mac).

## Assumptions to confirm
Solenoid and controller were replaced; total spend about $1,000. Change the lines if not.

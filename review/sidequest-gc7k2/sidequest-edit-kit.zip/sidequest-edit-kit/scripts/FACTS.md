# Facts + footage sheet: "$600 golf cart" (Sidequest Builds)

## Verified facts (may be stated)
- 2012 Yamaha G29 (Drive), electric. Bought for $600.
- It would not turn on / could not get it to run: batteries all gone (bare wires in an empty battery bay), no solenoid, controller not working, a couple of broken wires. He said: "We think the engine's good, but haven't verified it since we can't get it to run yet."
- Lights were sun-damaged ("seen a lot of damage in the sun"). Body: oxidation, chips, dents, messed-up pinstripe, a worn edge ("main issue"). He said: "I thought about repainting this, but I think for the price, I'm planning just to buff it."
- Floor "looks pretty good, I think I'm going to be able to save this."
- Work shown: roof off, seat off, lights out, wiring nest, body off, pressure wash, scrub, machine buffing/polishing of the white body, black trim restorer on the faded gray plastic (YAMAHA panel goes gray to black), frame/struts spray-painted black at night under string lights, reassembly, new battery installed (looks like a single compact battery), new black steering wheel, new diamond-stitch black seat, new windshield work, new rims/tires, LED headlights, golden-hour reveal on grass.
- Proof of power: the tail lights glow red on camera (original 8:46 and 8:52). That is the only power proof.
- Location: Arizona-style suburb (desert landscaping). Do not name a city.
- Channel voice: a 20-something guy, calm, first person "I". Another pair of hands helps at points; don't name anyone.

## NOT known (never state as fact; you may write a line that needs it ONLY if marked [CONFIRM: ...])
- Total spend, parts costs, resale value, time taken (days/weeks), whether it's his first golf cart / first build of this kind, where/how he bought it, how long it sat, whether it drives (NO driving shot exists).
- Do not promise driving. Do not promise a cost total or value unless marked [CONFIRM].

## Footage available (original video timecodes, seconds)
- 0.4-5: beat-up cart walkaround in garage (front 3/4, bright garage)
- 6-10: seat lifted, EMPTY battery bay with bare wires
- 12-16: dead controller close-up
- 17-19: rear of cart with bay open
- 21-27: faded headlight, him pointing at it
- 31-39: body oxidation; 40-43 stained tan seat; 44-47 chalky chipped body edge with finger pointing
- 48-59: walkaround, side views
- 60-127: teardown: armrests, windshield, ROOF LIFTED OVERHEAD (90-94), seat lifted (96-100), cowl off, headlight drilling, taillight out (red lens)
- 138-141: wiring nest (hands in a tangle of old wires)
- 142-206: body panels pried off, body off the frame
- 222-246: outside: pressure wash, scrubbing the body on gravel
- 250-286: machine buffing the white body, wiping to a shine
- 300-307: dusk, frame parts in the driveway
- 308-323: NIGHT spray painting under string lights (cinematic)
- 332-346: trim restorer: faded gray YAMAHA panel wiped to deep black (very satisfying)
- 360-420: restoring black plastics with gloves, floor mat
- 426-470: body back on, garage timelapse reassembly
- 474-499: roof back on, new steering wheel (480), windshield (486-492)
- 500-516: new battery going into the bay, diamond-stitch seat visible
- 517-534: cart sitting finished in garage; TAIL LIGHTS GLOW RED at 527 and 533 (wide shot, brief)
- 535-551: new rims/tires being installed with a floor jack
- 552-559: rim close-up, LED headlight close-ups, new steering wheel
- 560-562: finished cart on the street; 562-566 diamond seat, red tail light close-up; 567-569 black YAMAHA panel
- 571.5-582: golden-hour reveal on grass (front, orbit, rear, side)

## On-screen graphics available
$600 price tag; rubber stamp (e.g., DEAD, NO REPAINT); simple checkbox list (BATTERIES, SOLENOID, CONTROLLER, BODY, MAKE IT TURN ON) that can tick off; "SPENT SO FAR" ticker (only $600 is known now); step slates ("STEP 1 · TEAR IT DOWN"); before/after split; white flash + impact on reveal; punch-in zooms on key words.

## Voice
VO will be TTS (Google Chirp3-HD male US) until he re-records. Target ~3.3 words/second. Lines must be sayable by a calm 20-something builder. No em dashes. Never the words "honest", "genuine", "truthful". No "journey", "transformation" (as a noun), "epic", "stunning", "let's dive in", "you won't believe", hype-man energy, greetings or channel plugs before the hook.

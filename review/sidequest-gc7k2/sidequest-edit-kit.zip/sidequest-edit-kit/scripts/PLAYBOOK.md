# Sidequest Builds: Hook + Talk-Track Playbook

Built 2026-10-09 from 44 outlier videos across 20 channels. Every quote below is verbatim from YouTube's original-language English auto captions (`en-orig`) or the creator's own manual captions, timestamped. Where data was missing, it says so.

Files:
- `corpus.json`: per-video metadata, outlier ratio, word-timing stats, opening metrics, hand annotations (archetype, first line, problem, stakes, open loop, payoff promise, thumbnail breakdown).
- `transcripts/<id>.txt`: cleaned opening (0-120s) + closing (last 60s). `transcripts/<id>.full.txt`: full timestamped transcript.
- `thumbs/<id>.jpg` and `thumbs_grid.png`: every corpus thumbnail, labeled with views and outlier ratio, sorted by ratio.
- `pacing.json`: cut counts in the first 30s for 14 videos. `rehooks_raw.txt`: mid-video re-hook lines mined from all transcripts.
- `lists/`: raw 60-upload listings per channel, `channel_stats.json` with medians.

---

## 0. Method (so the numbers can be trusted)

**Channel selection.** Required channels were all pulled (Mat Armstrong, Tavarish, B is for Build, ChrisFix, Goonzquad, Hoovies Garage, Vehicle Virgins, WhistlinDiesel, Cleetus McFarland, Hand Tool Rescue, My Mechanics). Golf-cart channels came from YouTube searches for "golf cart restoration", "cheap golf cart", "$500 golf cart" and "bought broken golf cart" (`lists/searches.txt`); the ones with real outliers were **Luke Peavy Golf** (a golf channel whose cart rebuild hit 25x its median), **Ultimate Rebuilds**, **Atlantic Beach Customs** (a $600 cart, the exact price as ours), **Spicer Designs** and **2vintage** ("Seller said it won't run" format, includes a golf cart). House channels: **Havesomevision** (8.7M abandoned-house video, 484x) and **MattBangsWood** ("Cheapest House I Could Find", 2.1M).

**"Preston Go"** most likely means **@prestongoes** (Preston Goes): a build channel, "I Built a Go-Kart for Abandoned Railroads", median 914K. Searching "Preston Go" also returns **@PrestonYT** (Preston Arsement, gaming/challenge, 11M+ views), which is not a build channel. Ambiguity noted; prestongoes is used.

**Outlier ratio** = video views / median views of that channel's last 60 long-form uploads (Shorts and videos under 3 min excluded). Four older videos (marked `*`) are outside the 60-upload window; their ratio still uses the recent median, so it overstates them a little. View counts in listings are rounded by YouTube; the corpus uses exact counts from each video page. Recent uploads have had less time to collect views, so their ratios are conservative.

**Transcripts.** `yt-dlp --write-auto-subs`. Important finding: for many channels the `en` caption track is a machine re-translation (it produced lines like "the Chinese drawing is here" for "the Chinese blueprint over here"). All auto tracks were re-pulled as `en-orig`, which is the real speech recognition of what the creator said. Three My Mechanics / Hand Tool Rescue videos have no speech and no captions. Auto captions have no reliable punctuation, so sentence-length and question counts are approximate.

**Pacing.** First 31s of 14 videos at 360p (only muxed format 18 was served), `ffmpeg select='gt(scene,0.3)'`. Threshold 0.3 counts hard cuts only; a moving single shot (ChrisFix, Havesomevision) correctly reads as zero cuts. Frame strips every 3s were inspected visually to describe what's on screen.

**Limits.** n=44 and channels differ hugely in size, so feature-vs-ratio tallies are directional, not proof. Where a pattern only appears in 2-3 videos it is labeled as such.

---

## 1. Corpus

Sorted by outlier ratio. `*` = older than the 60-upload sample. "Money first said" is the first spoken price or dollar figure detected in captions (on-screen text not counted).

| # | Channel | Video | Views | Ratio | Archetype(s) | First word | Words 0-5s / 0-15s / 0-30s | Money first said |
|---|---|---|---|---|---|---|---|---|
| 1 | Havesomevision | [I BOUGHT an ABANDONED HOUSE & RENOVATED IT IN ONE YEAR / Start to Fini](https://youtu.be/zPeWu6oiA_c) | 8.7M | 483.74x | COST_LEDGER, REVEAL_FIRST | 0.2s | 12 / 38 / 93 | 91.0s |
| 2 | MattBangsWood | [I Bought the Cheapest House I Could Find To Remodel! [#1]](https://youtu.be/ZlZAfPIFOlo) | 2.1M | 50.63x* | PREMISE_CONTRAST, REVEAL_FIRST | 1.9s | 7 / 43 / 87 | never in speech |
| 3 | Hand Tool Rescue | [Rare Antique Fractal Vise [Restoration]](https://youtu.be/QBeOgGt_oWU) | 24.3M | 32.85x | SILENT | 1.5s | 3 / 3 / 3 | never in speech |
| 4 | Luke Peavy Golf | [Attempting to Rebuild a 30 Year Old Golf Cart!](https://youtu.be/q6BZwdijxuM) | 315K | 25.18x | CAN_I, CHEAP_DEAD | 0.0s | 17 / 52 / 109 | 272.8s |
| 5 | Spicer Designs | [I Was Quoted $2,000 to Raise My Concrete Slab - I Did It for Under $30](https://youtu.be/1vDAFZw9YYE) | 701K | 13.48x | COLD_OPEN, COST_LEDGER, CAN_I | 5.5s | 0 / 7 / 38 | 412.4s |
| 6 | Vehicle Virgins | [Picking Up UBER Riders In A Ferrari!](https://youtu.be/75sDKzzKTz0) | 859K | 13.43x | COLD_OPEN | 0.0s | 8 / 19 / 53 | 1027.4s |
| 7 | goonzquad | [We Bought Temu's Craziest Product!!!](https://youtu.be/bUkvDe0x47A) | 7.7M | 13.35x | COLD_OPEN, CAN_I | 0.0s | 12 / 39 / 94 | 238.5s |
| 8 | my mechanics | [1891 German ''Weltrekord'' Ratchet Screwdriver - Restoration](https://youtu.be/JmSXo0XdWoA) | 79.1M | 11.46x | SILENT | no speech | - | never in speech |
| 9 | prestongoes | [I Built a Go-Kart for Abandoned Railroads *Again*](https://youtu.be/stsGKb_KMmM) | 7.3M | 7.99x | REDEMPTION, CAN_I | 0.2s | 16 / 59 / 106 | 206.9s |
| 10 | Luke Peavy Golf | [Full Rebuild of an Abandoned Golf Cart!](https://youtu.be/UWcJPj9GI5I) | 98K | 7.87x | COST_LEDGER, CHEAP_DEAD | 0.0s | 16 / 42 / 81 | 51.5s |
| 11 | Ultimate Rebuilds | [Flipping CHEAP Wrecked Cars Off Facebook Marketplace](https://youtu.be/OSy3w9wclrA) | 891K | 7.3x | COST_LEDGER | 0.3s | 17 / 53 / 111 | 30.7s |
| 12 | 2vintage | [Seller Said This $150 SEIZED 1100cc Motorcycle Would Never Run (PROBLE](https://youtu.be/I0e8w5mpGuc) | 1.4M | 6.88x | CHEAP_DEAD, MYSTERY | 0.4s | 12 / 28 / 74 | 5.0s |
| 13 | Luke Peavy Golf | [Attempting to Start A 30 Year Old Golf Cart…](https://youtu.be/nErgQyKyrc8) | 76K | 6.09x | REDEMPTION, CHEAP_DEAD | 0.0s | 20 / 56 / 102 | never in speech |
| 14 | prestongoes | [My Homemade Jetpack Shouldn’t Work SO Well](https://youtu.be/t9Y_Nvtj5fs) | 5.1M | 5.58x | CAN_I, PREMISE_CONTRAST | 4.2s | 3 / 35 / 78 | never in speech |
| 15 | prestongoes | [I Built a Mini Truck for Abandoned Railroads](https://youtu.be/FgOJwFLF26k) | 4.6M | 5.0x | REDEMPTION, CAN_I | 0.1s | 23 / 61 / 109 | 83.4s |
| 16 | Ultimate Rebuilds | [I Bought a $1000 WRECKED Car to FIX and FLIP on Marketplace](https://youtu.be/0za2ivfPP8U) | 596K | 4.89x | CHEAP_DEAD, CLOCK, COST_LEDGER | 0.5s | 13 / 50 / 107 | 4.5s |
| 17 | WhistlinDiesel | [WhistlinDiesel Cybertruck Durability Test #1](https://youtu.be/PK_EJ3DyiiA) | 39.9M | 4.7x | CAN_I, COLD_OPEN | 0.0s | 11 / 16 / 32 | 150.8s |
| 18 | ChrisFix | [How to Detail Faded Paint by Hand (Paint Correction)](https://youtu.be/vUdSUDObwVc) | 17.8M | 4.35x | REVEAL_FIRST, COST_LEDGER | 0.0s | 17 / 54 / 110 | 9.0s |
| 19 | ChrisFix | [How to Fix a Car that Wont Start (I bought it for $500)](https://youtu.be/Bbi0kEaTgio) | 17.8M | 4.33x | CHEAP_DEAD | 0.3s | 13 / 47 / 99 | 7.1s |
| 20 | Ultimate Rebuilds | [EPIC Golf Cart Makeover](https://youtu.be/hB2bKvQiZ0c) | 450K | 3.69x | REVEAL_FIRST, SILENT | 30.6s | 0 / 0 / 0 | 493.5s |
| 21 | Tavarish | [I Bought A Flooded $2,000,000 McLaren P1 And It's Worse Than You Can I](https://youtu.be/rJNqj_QNkWM) | 5.8M | 3.62x | COLD_OPEN, SILENT | 65.3s | 0 / 0 / 0 | 106.7s |
| 22 | Mat Armstrong | [I BOUGHT A NON RUNNING £1.7M LUXURY YACHT](https://youtu.be/hBNgCuBTyaU) | 34.5M | 3.55x | PREMISE_CONTRAST, MYSTERY | 0.1s | 8 / 20 / 55 | 19.4s |
| 23 | goonzquad | [We Each Bought a $10,000 Diesel Truck](https://youtu.be/IONYE5lGWo8) | 1.8M | 3.17x | COLD_OPEN, CLOCK | 0.0s | 7 / 7 / 65 | 0.8s |
| 24 | ChrisFix | [How to Buy a Car To Flip for a Profit ($$$ Side Hustle)](https://youtu.be/uYRckB_g10I) | 12.9M | 3.14x | COST_LEDGER, MYSTERY | 0.7s | 19 / 53 / 117 | 15.9s |
| 25 | my mechanics | [Broken Rusty Oldtimer Scooter - Restoration](https://youtu.be/EVShbpzeh0E) | 21.7M | 3.14x | SILENT | no speech | - | never in speech |
| 26 | Hand Tool Rescue | [Why Did They Stop Making These? [Restoration]](https://youtu.be/gh0SV8aPnMU) | 2.2M | 2.95x | SILENT | no speech | - | never in speech |
| 27 | 2vintage | [Seller Said This Abandoned $600 2-Stroke Dirt Bike Won't Run (INCREDIB](https://youtu.be/LXexDlAoMY4) | 553K | 2.76x | MYSTERY, CHEAP_DEAD | 0.6s | 14 / 47 / 85 | 29.3s |
| 28 | Atlantic Beach Customs | [CRAZY $600 GOLF CART REBUILD - Street Legal Conversion](https://youtu.be/vXrpCZonH60) | 79K | 2.73x* | REVEAL_FIRST, COST_LEDGER | 0.3s | 21 / 48 / 119 | 14.7s |
| 29 | goonzquad | [We Rebuilt A Wrecked Cadillac V Blackwing Within 24 Hours](https://youtu.be/TujMKH4OQ_0) | 1.3M | 2.16x | CLOCK, COLD_OPEN | 6.6s | 0 / 21 / 64 | 35.4s |
| 30 | B is for Build | [Fully Restoring My Sunken 30 Year Old Italian Yacht](https://youtu.be/ANwWP2vvb9A) | 441K | 2.15x | CLOCK, REDEMPTION | 0.8s | 17 / 52 / 117 | 208.0s |
| 31 | Tavarish | [I Bought And Rebuilt A Wrecked Exotic Car You’ve Never Heard Of (1000 ](https://youtu.be/_HIFALOgSxM) | 3.3M | 2.09x | CLOCK, PREMISE_CONTRAST | 0.1s | 14 / 41 / 80 | 82.6s |
| 32 | WhistlinDiesel | [Buying A Peterbilt Semi and Destroying it EP1](https://youtu.be/WNBrskEjRX4) | 17.5M | 2.06x | COLD_OPEN | 0.1s | 7 / 34 / 93 | 194.5s |
| 33 | B is for Build | [I SAVED $23,000 By 3d Printing My Own Lamborghini Murcielago Headlight](https://youtu.be/4nJtWgtQgIM) | 416K | 2.03x | COST_LEDGER | 0.6s | 7 / 38 / 107 | 6.4s |
| 34 | Tavarish | [I Found A $2,000,000 Lamborghini Miura ABANDONED FOR 50 YEARS In A JUN](https://youtu.be/tBeL_vsZNBI) | 3.2M | 2.0x | PREMISE_CONTRAST, MYSTERY | 0.5s | 17 / 42 / 79 | 191.2s |
| 35 | Mat Armstrong | [I BOUGHT A FLOOD DAMAGED ROLLS ROYCE CULLINAN & REBUILT IT IN 7 DAYS](https://youtu.be/hk_BmN8lTxY) | 19.3M | 1.99x | CLOCK, COST_LEDGER | 0.1s | 13 / 33 / 75 | 118.3s |
| 36 | Cleetus McFarland | [I Might've Gone a Little Overboard...](https://youtu.be/6YFENfyphDc) | 2.9M | 1.8x | SPONSOR_FIRST | 0.1s | 17 / 62 / 115 | 64.4s |
| 37 | Spicer Designs | [I Bought The CHEAPEST Golf Cart I Could Find...](https://youtu.be/uHz0fFRf-88) | 90K | 1.73x* | COLD_OPEN | 16.2s | 0 / 0 / 30 | 549.4s |
| 38 | Mat Armstrong | [I BOUGHT A NON RUNNING BUGATTI VEYRON](https://youtu.be/HfA4hxPCA2o) | 16.3M | 1.68x | PREMISE_CONTRAST, MYSTERY | 0.0s | 10 / 30 / 77 | 144.0s |
| 39 | Hoovies Garage | [We discovered why my cheap Mercedes AMG GT was dumped at auction, and ](https://youtu.be/DE4my-zym7M) | 777K | 1.66x | MYSTERY, COLD_OPEN | 1.8s | 7 / 31 / 76 | 16.9s |
| 40 | Hoovies Garage | [My $2,000,000 Mercedes 300SL Gullwing is way more broken than I though](https://youtu.be/aaGMUg0fOWg) | 770K | 1.65x | CLOCK, REDEMPTION | 12.0s | 0 / 12 / 63 | 190.7s |
| 41 | Cleetus McFarland | [Cheap Racecar Challenge Ep.7 - The Sideways Turbo Disaster... Jackstan](https://youtu.be/PTORqnT_zT4) | 2.5M | 1.54x | COLD_OPEN | 0.0s | 11 / 23 / 57 | 148.6s |
| 42 | B is for Build | [I Bought a Salvage Mach-E With NO Keys… Will It Even Start?](https://youtu.be/_DQjy35msfY) | 302K | 1.47x | CAN_I, MYSTERY | 1.2s | 17 / 53 / 108 | 160.8s |
| 43 | Hoovies Garage | [I bought a cheap, high mileage R35 Nissan GTR, and here's why you shou](https://youtu.be/ScYU8Ylcegk) | 665K | 1.42x | CHEAP_DEAD, PREMISE_CONTRAST | 0.0s | 18 / 52 / 72 | 5.3s |
| 44 | 2vintage | [Seller Was Going To Scrap This 2-Stroke Golf Cart (HUGE MISTAKE)](https://youtu.be/OEl68C2ZA1U) | 129K | 0.65x | CHEAP_DEAD | 11.3s | 0 / 10 / 44 | 46.1s |

### Corpus-wide opening numbers (38 videos with speech)

| Metric | Median | Middle 50% |
|---|---|---|
| Time to first spoken word | 0.25s | 29 of 38 start talking within 1.0s |
| Words in first 5s | 12.5 | 7 to 17 |
| Words in first 15s | 40 | 22 to 52 |
| Words in first 30s | 83 | 65 to 107 |
| Words in first 60s | 178 | 145 to 208 |

The three golf-cart outliers from Luke Peavy say **81, 102 and 109 words** in the first 30s. The one golf-cart underperformer in the set (2vintage, 0.65x) says **44**, with its first word at 11.3s.

**Price timing.** In every video whose title sells a *cheap* price (sub-$1,000 or "cheapest"), the price is spoken by 15s, except two: 2vintage's dirt bike (29s, but it opens on "crazy good deal" at 0:00) and Spicer's cheapest golf cart (9:09, ratio 1.73x, the weakest cart outlier). ChrisFix 7.1s, Ultimate Rebuilds 4.5s, 2vintage 5.0s, Hoovies 5.3s, Atlantic Beach 14.7s. Seven-figure titles (Tavarish P1, Miura, Hoovies 300SL) delay the spoken price to 1:46-3:10 because the thumbnail already shouts it.

### Cut pacing, first 30 seconds

| Video | Ratio | Cuts 0-10s | 10-20s | 20-30s | Avg shot (s) | First cut (s) | What the first 30s shows (from frame strips) |
|---|---|---|---|---|---|---|---|
| Havesomevision: I BOUGHT an ABANDONED HOUSE & RENOVATED IT IN | 483.74x | 0 | 0 | 0 | 30.0 | None | Single slow push-in on the ivy-covered house |
| Hand Tool Rescue: Rare Antique Fractal Vise [Restoration] | 32.85x | 0 | 0 | 0 | 30.0 | None | Hands turning the broken vise, single close-up |
| Luke Peavy Golf: Attempting to Rebuild a 30 Year Old Golf Cart | 25.18x | 4 | 6 | 4 | 2.0 | 4.5 | Carrying new parts, cart on trailer, batteries, rust, selfie talk, Vatrer battery box |
| prestongoes: I Built a Go-Kart for Abandoned Railroads *Ag | 7.99x | 6 | 4 | 6 | 1.8 | 1.2 | Kart on rails, broken part, him, 'I love bridge' shirt, hand-drawn attempt map, 'Tunnels' title |
| 2vintage: Seller Said This $150 SEIZED 1100cc Motorcycl | 6.88x | 0 | 0 | 0 | 30.0 | None | Bike on trailer, slow walkaround (handheld, no cuts) |
| Luke Peavy Golf: Attempting to Start A 30 Year Old Golf Cart… | 6.09x | 5 | 7 | 4 | 1.8 | 2.1 | '$750' overlay on rusty cart, 'Coming Up...' card, failed key turn, mechanic |
| WhistlinDiesel: WhistlinDiesel Cybertruck Durability Test #1 | 4.7x | 3 | 2 | 7 | 2.3 | 3.9 | On-screen question 'ARE CYBERTRUCKS AS DURABLE AS ELON...' 'LET'S FIND OUT', drone, dark title sequence |
| ChrisFix: How to Fix a Car that Wont Start (I bought it | 4.33x | 0 | 0 | 0 | 30.0 | None | One continuous POV shot: winching the SUV onto the driveway while talking |
| Ultimate Rebuilds: EPIC Golf Cart Makeover | 3.69x | 3 | 3 | 1 | 3.8 | 2.6 | No speech: EZGO badge, cart, batteries, then FINISHED cart in studio by ~0:27 |
| Tavarish: I Bought A Flooded $2,000,000 McLaren P1 And  | 3.62x | 0 | 0 | 3 | 7.5 | 23.6 | Black title card 'September 28th, 2022', flood footage, 'Three months later', Tavarish at laptop |
| Mat Armstrong: I BOUGHT A NON RUNNING £1.7M LUXURY YACHT | 3.55x | 8 | 5 | 7 | 1.4 | 0.0 | Rapid montage: Mat + Bugattis, auction table, yachts with on-screen sale prices |
| goonzquad: We Each Bought a $10,000 Diesel Truck | 3.17x | 5 | 5 | 0 | 2.7 | 2.4 | Cold-open truck haggling, bent chassis, then 3-person intro |
| Atlantic Beach Customs: CRAZY $600 GOLF CART REBUILD - Street Legal C | 2.73x | 1 | 0 | 3 | 6.0 | 8.4 | Selfie talking head in shop |
| Hoovies Garage: We discovered why my cheap Mercedes AMG GT wa | 1.66x | 1 | 1 | 2 | 6.0 | 9.2 | In-progress shop scene with mechanic, under-car leak shots, clean car beauty shot |

Median average shot length across the 14: **4.9s**, but it is bimodal. Story/challenge openers cut every 1.4-2.7s (Mat Armstrong 1.4s, prestongoes 1.8s, Luke Peavy 1.8-2.0s, Goonzquad 2.7s). Tutorial/walkaround openers hold one moving shot (ChrisFix, 2vintage, Havesomevision) and carry the energy with dense talk instead (ChrisFix: 99 words in 30s). The one measured opener with both zero cuts and slower talk (2vintage Gold Wing, 2.47 words/s) compensates with a price in the first 5s (`$150 find`) and the seller's verdict by 1:46.

---

## 2. The 10 rules (evidence-backed)

### First 5 seconds

**Rule 1. Say the title's promise out loud in the first sentence, in plain words.**
Speech starts at a median 0.25s, and the first sentence is usually the title rephrased.
- Luke Peavy, "Attempting to Start A 30 Year Old Golf Cart..." (6.09x): `[00:00] I bought the cheapest golf cart I could find and it did not even run.`
- ChrisFix, "How to Fix a Car that Wont Start (I bought it for $500)" (4.33x): `[00:02] At the end of this winch cable is a car I just got for five hundred dollars It doesn't run It doesn't drive`
- Ultimate Rebuilds, "$1000 WRECKED Car" (4.89x): `[00:00] This right here is a 2012 Ford Focus that I only paid $1,000 for.`
- prestongoes, "Mini Truck for Abandoned Railroads" (5.0x): `[00:00] this is a Japanese mini truck and I'm going to get it to ride on abandoned railroads here's why`
Matches the leaked MrBeast memo as reported by Gigazine: the first minute "shows that the thumbnail meets the expectations."

**Rule 2. Price + broken state in the same breath, by 5 seconds, when the price is the hook.**
The cheap-price videos pair the number with what's wrong immediately: ChrisFix ($500 + "doesn't run" by 0:09), Ultimate Rebuilds ($1,000 @0:00 + "the reason I got it so cheap is because it is wrecked" @0:05), Hoovies (`[00:03] To buy an R35 GT-R for under $50,000, it has to have three different things wrong with it.`), 2vintage (`[00:05] $150 find.`).

**Rule 3. Open on the object, not the creator's intro.** "Welcome back" first is rare among top outliers. Goonzquad, Hoovies and Vehicle Virgins all put a cold-open moment *before* "What is up guys / Welcome to Hoovie's Garage." ChrisFix's "Hey guys ChrisFix here" lasts 2 seconds and is spoken over the winch shot. The weakest opener in the B is for Build set (1.47x) is the only one that spends 0:22-2:00 on backstory ("this is a very long story").

### First 30 seconds

**Rule 4. Ask exactly one yes/no question by 0:30, and make it about the machine.**
- Luke Peavy (25.18x, the biggest golf-cart outlier found): `[00:32] Can a guy who's never done this before actually make this golf cart run?`
- 2vintage (2.76x): `[00:04] either the seller didn't know what he had or this thing has something majorly wrong with it that the seller was hiding. [00:13] I guess we're going to find out today.`
- B is for Build title: "Will It Even Start?"; WhistlinDiesel (4.70x) `[00:00] are cyber trucks as durable as Elon says are let's find out`

**Rule 5. Name the specific failures. Lists of three are the house style.**
- Luke Peavy: `[00:13] It didn't run, the batteries were dead, the wiring was a mess`
- Luke Peavy: `[00:11] A new lithium battery, a new motor, a new controller.`
- Hoovies: `Number one, it has to have accident history. Number two, it has to have high mileage. And number three, uh it has to look like this.`
- prestongoes: `[00:19] this time we face three new obstacles tunnels turns and distance`

**Rule 6. Plant a specific payoff the viewer can hold you to, then deliver it.**
- 2vintage: `[01:54] by the end of the video, start it and drive it.` / `[01:57] the first goal is to get this thing up, running, and driving by the end of the video.`
- ChrisFix: `[00:17] So we'll spend less than a thousand dollars to get a really nice running and driving car.` Closed @29:02: `So $900 in total And this car right now as it sits, is worth about $3,000, so a $2,100 profit`
- Havesomevision (484x): `[00:16] I'm going to say exactly what we paid for it, how much it cost to renovate and after just over a year of working on it how much we had it valued` Closed @20:45: `we got it valued at 1.75 million`
- Luke Peavy: `[00:02] today we're finding out exactly how much it actually cost. [00:09] For a total price of` (cut before the number; answered @45:36-46:29).
Only promise what the footage can deliver (see Section 8: we have no driving shot).

**Rule 7. Show the finish (or the stakes) on screen before 0:30, even if you don't say it.**
Ultimate Rebuilds' golf cart (3.69x) says nothing for 30s and runs a montage that ends on the finished cart around 0:27, then says `[00:50] it's going to go from this to this`. ChrisFix's paint video says "from this to this" four times before 1:45. Mat Armstrong flashes yacht sale prices on screen in his first 30s. Atlantic Beach's $600 cart: `[00:28] here's a glimpse of what we...` followed by the finished cart.

### The body

**Rule 8. Re-hook with small tests every few minutes: "Let's see if..."**
Mined counts (`rehooks_raw.txt`): 2vintage's 77-minute Gold Wing video has 13 test beats ("Let's see if we're getting any power down to the solenoid" @22:57, "Let's see if the bike turns over now" @61:29). ChrisFix: @4:47, @8:32 ("Let's see if she'll start"), @9:48, @13:37, @23:43. This lines up with the reported memo practice of re-engagement at 3 and 6 minutes (Gigazine summary).

**Rule 9. Let something fail on camera, early. The failure is the re-hook.**
- ChrisFix: `[06:21] Let's go try to start it anyway Ahhh, That's not good.` `[06:28] Okay, so our starter isn't functioning either`
- Luke Peavy: `[00:42] And it wasn't long before I had my first problem.` Then at the climax: `[17:00] It's time for the moment of truth.` `[17:14] I didn't hear anything click.` That failure became the next video (6.09x).
- Mat Armstrong (Cullinan): `[37:08] the bad news is ... the good news`

**Rule 10. End on the proof, then the ledger, then leave fast.**
Endings across the corpus: proof moment (start/drive/valuation), money tally, one line of feeling, subscribe ask, out. ChrisFix @29:02 ledger then subscribe. Mat Armstrong @73:46 parts total vs purchase price, then "I'll let you guys decide." Atlantic Beach @12:36 "So this ended up being my total." Nobody in the corpus asks for a subscribe before the payoff.

---

## 3. Hook archetypes

Archetype tags in the corpus (a video can carry two): COLD_OPEN 11, COST_LEDGER 10, CHEAP_DEAD 9, MYSTERY 8, CAN_I 8, PREMISE_CONTRAST 7, CLOCK 7, SILENT 6, REDEMPTION 5, REVEAL_FIRST 5, SPONSOR_FIRST 1.

### A. Cheap + Dead ("I bought X for $N and it doesn't run")
**Definition.** Price and broken state in the first sentence; the video is the fix.
**Template.**
1. Object + price: "This is a [year model] I bought for [$N]."
2. What's dead (specific): "It doesn't [run/turn on]. [Failure 1], [failure 2], [failure 3]."
3. Why that's interesting: "[Seller said / most people would have] [scrapped it]."
4. Today's goal: "Today I'm going to [get it running] [for under $X]."
**Examples.**
- ChrisFix, "How to Fix a Car that Wont Start (I bought it for $500)", 17.8M, 4.33x: `At the end of this winch cable is a car I just got for five hundred dollars It doesn't run It doesn't drive`
- Luke Peavy, "Attempting to Start A 30 Year Old Golf Cart...", 76K, 6.09x: `I bought the cheapest golf cart I could find and it did not even run. Most people would have scrapped it. Instead, I decided to see if I could bring it back to life.`
- 2vintage, "Seller Said This $150 SEIZED 1100cc Motorcycle Would Never Run", 1.4M, 6.88x: `Well, we just bought another massive bike here. Check this thing out. $150 find.` ... `he believes the engine is junk`
- Ultimate Rebuilds, "$1000 WRECKED Car", 596K, 4.89x: `This right here is a 2012 Ford Focus that I only paid $1,000 for. And the reason I got it so cheap is because it is wrecked in the front end.`
**Fits when** the price is low enough to be a joke and the failure is concrete.

### B. Can I? (challenge question, ideally with a beginner admission)
**Definition.** A yes/no question about whether the creator can pull it off, with a plain admission of inexperience as the stakes.
**Template.**
1. Where it started: "[Object] was [state] for [time]."
2. Specific damage list.
3. Why I did it anyway (one personal line).
4. The question: "Can a guy who's never [done X] actually [make it Y]?"
**Examples.**
- Luke Peavy, "Attempting to Rebuild a 30 Year Old Golf Cart!", 315K, **25.18x**: `This cart was sitting abandoned behind a house for years.` ... `But I picked it up for cheap because I thought it deserved a second chance and I've never had a golf cart.` ... `Can a guy who's never done this before actually make this golf cart run?`
- prestongoes, "My Homemade Jetpack Shouldn't Work SO Well", 5.1M, 5.58x: `if Wikipedia had a list of people that could probably build a jetpack that' be at the bottom for sure`
- Spicer Designs, "Quoted $2,000 to Raise My Concrete Slab", 701K, 13.48x: `I have no idea if it's going to work or if it's going to fail. Either way, I'm still going to post this video.`
- WhistlinDiesel, "Cybertruck Durability Test #1", 39.9M, 4.70x: `are cyber trucks as durable as Elon says are let's find out`
**Fits when** the creator is not an expert (true for Sidequest) and the answer is visible on camera.

### C. Reveal-first / "from this to this"
**Definition.** Show the after inside the first 30s, then rewind. The question shifts from "will it work" to "how did it get there".
**Template.**
1. (Visual) before shot, then flash of the after.
2. "This [object] went from this... to this."
3. The surprising method or constraint: "And I didn't [the obvious thing]."
4. "Here's how, and what it cost."
**Examples.**
- Ultimate Rebuilds, "EPIC Golf Cart Makeover", 450K, 3.69x: silent 30s montage ending on the finished cart, then `this right here is a 2003 easygo txt golf cart that I paid next to nothing for` ... `by the time I'm finished with it it's going to go from this to this`
- ChrisFix, "How to Detail Faded Paint by Hand", 17.8M, 4.35x: `It's oxidized. It's faded. It's all swirled up So i'm gonna show you how to detail this and paint correct it so we go from this to this`
- Atlantic Beach Customs, "CRAZY $600 GOLF CART REBUILD", 79K, 2.73x: `within minutes, you're going to see from beginning to end how we transformed our 1997 EasyGo TXT. I found it on marketplace for I think $600`
- Havesomevision, abandoned house, 8.7M, 484x: `I am going to be showing you the start to finish of this entire project`
**Fits when** the after shot is beautiful and the method has a twist.

### D. Cost Ledger ("exactly what it cost")
**Definition.** Promise a final number up front; withhold it.
**Template.** "I bought [X] for [$N]. [Did the work]. Today you find out exactly what it cost, and what it's worth now."
**Examples.** Luke Peavy "Full Rebuild of an Abandoned Golf Cart!" 98K, 7.87x (`today we're finding out exactly how much it actually cost. For a total price of`); Havesomevision (paid / renovation cost / valuation); ChrisFix flip, 12.9M, 3.14x (`a couple grand for a weekend's worth of work`); Atlantic Beach (`I'll tell you right now, I spent way too much.`).
**Fits only when** you have real totals. **We currently don't** (Section 8).

### E. Mystery ("why was it so cheap?" / "seller said it would never run")
**Template.** "Either [seller didn't know what he had] or [something's badly wrong]. We're going to find out today."
**Examples.** 2vintage dirt bike, 553K, 2.76x (quoted in Rule 4); Hoovies "why my cheap Mercedes AMG GT was dumped at auction", 777K, 1.66x (`clearly I have made a big big mistake here`); Mat Armstrong yacht, 34.5M, 3.55x (`I've just been offered one with a small problem which I think could mean it will be a bargain`).
**Fits when** the cause of death is unknown at purchase.

### F. Redemption ("I tried and it still didn't work")
**Template.** "Last time, [it failed]. This time, [new plan]. [Specific new obstacle list]."
**Examples.** prestongoes "*Again*", 7.3M, 7.99x (`my go-kart broke on the way there and I sadly never got to see my bridge`); prestongoes mini truck, 5.0x (`I've tried and failed two separate times`); Luke Peavy (`After all that work and I turned the key, well, it still didn't run.`); Hoovies 300SL (`it was kind of a false win`).
**Fits** a part 2, or a video where a mid-build failure happened.

### G. Ticking clock
**Template.** "I have [N days/hours] to [goal] because [real reason]."
**Examples.** Mat Armstrong Cullinan 7 days, 19.3M, 1.99x; Goonzquad "24 HR REBUILD", 2.16x; B is for Build yacht before the 4th of July, 2.15x; Hoovies 300SL rally in days, 1.65x.
**Fits** only with a real deadline. We have none on record.

### H. Cold open / in medias res
**Template.** 3-15s of the most intense moment (often audio-led: "Aw, come on", "Damn it"), then the setup.
**Examples.** Spicer slab (`Damn it. Piece of crap. Damn it.` then `Knowing what I know now, I can tell you one thing that I would not have done.`), 13.48x; Goonzquad Temu (`Was the Temu drone worth it?` ... `WE FREAKING FLEW.`), 13.35x; Vehicle Virgins Uber, 13.43x.
**Fits** when there's a strong live-audio moment. TTS VO can't fake that; it needs real captured audio.

### I. Premise contrast (status setup)
**Examples.** Mat Armstrong `The average Bugatti owner owns 64 cars, three helicopters, three jets, and one yacht. Today, we're going to bring down that average.` (34.5M, 3.55x). Works for huge-price objects; weak for a $600 cart.

### J. Silent restoration (contrast)
Hand Tool Rescue's 24.3M vise (32.85x) has three captions in 30s ("Patented in 1913"). My Mechanics (79M, 11.46x) has none. Their hook is entirely the object close-up and ASMR. This works for a channel built on that promise; for a talking creator whose viewers leave by 0:30 it is not a fit.

---

## 4. Scoring rubric for a candidate opening (blind judge)

Score the first 30 seconds of script (plus shot notes) 0-10 on each. Total out of 80.

| # | Criterion | 0 | 5 | 10 |
|---|---|---|---|---|
| 1 | **Title match by 5s** | Title promise not said or shown in 5s | Implied or said by 10s | First sentence says the title's promise in plain words, on a shot of the object |
| 2 | **Price + problem speed** | Price/problem absent from first 30s | One of the two by 15s | Price AND a specific failure stated by 8s |
| 3 | **One clear question** | No question; just a tour | Question implied or vague | One yes/no question about the machine, stated by 0:30 |
| 4 | **Deliverable payoff** | Promises something the footage can't show, or no promise | Vague promise ("it turned out great") | Specific payoff that the video verifiably shows later |
| 5 | **Specificity** | Generic ("it was in rough shape") | Some numbers | Model/year, price, and 2-3 named failures |
| 6 | **Visual proof density** | Talking head or static shots with no cuts and slow talk | Shots support the VO most of the time | Every claim has its shot; a shot change or major move every 2-3s, or one strong moving shot with 90+ words |
| 7 | **Voice** | Ad copy, hype adjectives, AI tells | Mostly natural | Sounds like one guy in a garage: contractions, a self-aware line, plain price talk |
| 8 | **Economy** | Greeting, backstory, sponsor or channel plug before the hook | One wasted line | Zero throat-clearing; 75-110 words in 30s; nothing a viewer could skip |

### Calibration (scored from the real transcripts)

**Luke Peavy, "Attempting to Rebuild a 30 Year Old Golf Cart!" (25.18x). Score 66/80.**
Title match 9 (`getting it to actually run` @0:00). Price/problem 6 (problems by 0:13; price only "cheap", the $4,000 is on the thumbnail). Question 10 (@0:32, slightly late). Payoff 8 (start attempt shown; it fails, which he converts to a cliffhanger). Specificity 8 (batteries dead, wiring a mess, motor/battery/controller). Visual 9 (cut every 2.0s). Voice 9 ("thought that'd be a cool transition"). Economy 7 ("Last episode we tore this golf cart completely apart" is recap).

**ChrisFix, "How to Fix a Car that Wont Start (I bought it for $500)" (4.33x). Score 69/80.**
Title match 10. Price/problem 10 ($500 + "doesn't run, doesn't drive" by 0:09). Question 6 (framed as a how-to promise, not a question). Payoff 10 (running @9:48, $900 vs $3,000 ledger @29:02). Specificity 8. Visual 8 (one continuous winch POV, 99 words). Voice 7 (friendly, teacher-ish, "With common hand tools!"). Economy 10.

**2vintage, "Seller Was Going To Scrap This 2-Stroke Golf Cart" (0.65x, underperformer). Score 25/80.**
Title match 3 (first words at 11.3s: `this is not typically something I would buy`). Price/problem 3 ($400 @0:44, "does not run" @1:01). Question 1 (none). Payoff 2 (none stated). Specificity 6 (Columbia Par Car, two-stroke, 10 hp). Visual 3 (letterboxed, slow). Voice 5. Economy 2. Same channel's dirt bike video, which opens with the seller mystery in 4 seconds, did 2.76x.

---

## 5. Voice guide

### What top garage creators sound like (verbatim)
- **Prices are said casually, as "bucks" or "grand":** 2vintage `I got this thing for 150 bucks. Crazy good deal.`; Luke Peavy `It's actually not that bad for 750 bucks.`; Hoovies `replacing it 30 40 grand`; Mat Armstrong `he got quoted 100 grand to repair this apparently. Yeah, I'll take 50.`
- **Short declaratives, often fragments:** `It doesn't run It doesn't drive` (ChrisFix). `Not once.` (Luke Peavy). `Crazy good deal.` (2vintage).
- **Self-deprecation as credibility:** `I know nothing.` (Luke Peavy @0:48). `the advertising major from the University of Georgia` (prestongoes). `Welcome to Hoovie's Garage, the dumbest automotive channel in all of YouTube.` `I just did something really really dumb` (Tavarish).
- **One oddly specific personal line:** `I really love bridges for some reason` (prestongoes). `Poop brown. Can't get much better than that.` (2vintage). `And it has purple wheels.` (Hoovies).
- **Vehicle as "she", work as "this thing":** `Let's see if she'll start` (ChrisFix), `Let's make this thing run.` (Luke Peavy).
- **Openers start with "Well," / "So," / "This right here is":** 2vintage `Well, we just bought...`; Ultimate Rebuilds `This right here is a 2012 Ford Focus`.
- **Contractions everywhere, first person singular.** In the first 30s the corpus uses "I/I'm/my" far more than "we" for solo creators (prestongoes 8-9 per 30s, Luke Peavy 6-7).
- **Talk speed** of a solo creator in the first 30s: about 2.7-3.6 words per second (Luke Peavy 2.7/3.4/3.6, prestongoes 3.5/3.6, ChrisFix 3.3). TTS should land near 3.3, not slower.

### Anti-patterns (things that read as ad copy or AI)
From the data:
- Greeting or channel plug before the hook (2vintage cart, Atlantic Beach's `What's going on, YouTube?` on a 79K video).
- Backstory before the question (B is for Build Mach-E: Tesla tangent 0:22-2:00; its weakest outlier).
- Sponsor read first (Cleetus does it, at a 1.6M median with a loyal audience; a small channel can't).
- Silence or ambient footage before speech, unless it ends on the finished product by ~0:27 (Ultimate Rebuilds does this; 2vintage's cart doesn't, and it is the corpus's worst ratio).
- Recap of the last episode as line 1.

House style (Sidequest-specific, not from the corpus data):
- No em dashes in scripts or captions. No "the h-word / g-word / t-word" filler (Nate's banned-words list). Several corpus creators use the h-word as filler; don't copy it.
- No "journey", "transformation" as a spoken noun, "epic", "stunning", "breathtaking", "game-changer", "let's dive in", "you won't believe", "not just X, it's Y", triple-adjective stacks, rhetorical questions answered by the next line in a bit voice.
- No hype-man energy. Mentored by MrBeast is not a license to sound like him; the outlier voices here are calm (ChrisFix, Luke Peavy, prestongoes, 2vintage).
- Never promise what the cut doesn't show.

---

## 6. MrBeast memo cross-reference

Verified sources: Gigazine's English summary of the leaked production document and Creator Handbook's excerpt. Direct quotes from the document that those sources reproduce:
- "CTR is what dictates what we do for videos." and "A simple way to up that CTR even more would be to title it 'I Survived' instead of 'I Spent.'" (Creator Handbook)
- "We lost 21 million viewers in the first minute of the video" (Creator Handbook)
- "Anytime we do something that no other creator can do, that separates us in their mind and makes our videos more special to them" (Creator Handbook)

Reported (paraphrase, Gigazine): the first minute must show the thumbnail's expectations are met; re-engagement moments are placed around minute 3 and minute 6; a video should ideally include an element of surprise ("wow factor").

| Memo principle | What the corpus shows | Rule |
|---|---|---|
| First minute matches thumbnail/title | Median first word 0.25s; first sentence restates title | 1, 2 |
| Re-engage around 3 and 6 minutes | "Let's see if..." test beats every few minutes; first failure at 0:42-6:28 | 8, 9 |
| Surprise / wow | Reveal flashes by 0:27 (Ultimate Rebuilds), cold opens (Goonzquad, Spicer) | 7 |
| Payoff the click | Ledger + proof endings, specific payoff planted in the hook | 6, 10 |
| No slow pacing | Story openers cut every 1.4-2.7s; static openers talk at 3.3+ wps | 6 (rubric) |

---

## 7. Thumbnails

Full contact sheet: `thumbs_grid.png` (44 thumbnails, sorted by ratio). Per-thumbnail breakdown in `corpus.json` under `annotation.thumb`.

### Tallies (n=44; directional only)
| Feature | n | Median outlier ratio |
|---|---|---|
| Has text | 25 | 3.69x |
| No text | 19 | 2.76x |
| Has a number/price | 12 | 3.98x |
| Before/after in one frame | 6 | 4.02x |
| Problem-only (just the broken thing) | 20 | 2.85x |
| Creator face visible | 24 | 2.67x |
| No creator face | 20 | 3.66x (inflated by the silent-restoration channels at 11-33x) |

### Patterns
1. **Before/after in one frame, same angle.** Luke Peavy (7.87x: rusty green cart left, red cart right, him centered holding the key, words "BEFORE" / "AFTER"), Ultimate Rebuilds golf cart (3.69x: before in a circle inset, red arrow, "START TO FINISH"), Ultimate Rebuilds Focus ($1000 / $5000 split, 4.89x), ChrisFix paint (Before/After split, 4.35x), Atlantic Beach $600 cart (inset + "START TO FINISH!").
2. **One number, huge.** Luke Peavy "$4,000" (25.18x), ChrisFix "$500 SUV" and "$2,700 -> $8,000", MattBangsWood "$79,500 -> $250,000" (50x), Spicer "$300 DIY FIX", Tavarish "$2,000,000" crossed out "WORTHLESS". Text is 1-5 words; the number does the work.
3. **Title complements, never repeats.** Luke Peavy: thumbnail "$4,000" / title "Attempting to Rebuild a 30 Year Old Golf Cart!". ChrisFix: thumbnail "$500 SUV" / title "How to Fix a Car that Wont Start". Near-repeats exist and still work on established channels (B is for Build "RESTORING A SUNKEN YACHT" over "Fully Restoring My Sunken 30 Year Old Italian Yacht", 2.15x; Goonzquad "$10K DIESELS", 3.17x), so this is a best practice, not a hard rule from this data.
4. **Face: reaction close-ups belong to big personality channels.** Mat Armstrong (grin + key), Hoovies (shocked inset), Tavarish (worried hand-on-head). In the golf-cart niche, the winning faces are **full-body, standing with the cart**, often holding the key (Luke Peavy 3 of 3).
5. **Bright, saturated, clean backgrounds.** Most top-15 thumbnails are bright daylight scenes with saturated color; the dark, letterboxed 2vintage golf cart is the lowest ratio in the corpus (0.65x). Its same-channel dirt bike and Gold Wing thumbnails are also letterboxed and did 2.76x and 6.88x, so the title ("Seller Said...") is doing that channel's work.

### Thumbnail rubric (0-10 each, total 60)
| # | Criterion | 10 looks like |
|---|---|---|
| 1 | Readable at phone size | One subject, max 1-5 words, high contrast |
| 2 | Shows the change or the stakes | Before/after same angle, or the one number that makes it absurd |
| 3 | Number | A single price in big type ("$600") |
| 4 | Title complements | Title adds a fact the image can't (year, model, "wouldn't turn on") |
| 5 | Human presence | Creator in frame with the object, natural expression, key in hand |
| 6 | Promise is in the video | The after shot in the thumbnail is a real frame from the reveal |

### What our golf cart thumbnail should borrow
- **Before/after split of the cart from the same angle**, with "$600" in big type. This is the format of the Luke Peavy 7.87x and both Ultimate Rebuilds golf-cart/flip outliers.
- After half = a golden-hour frame with **tail lights glowing**, since that's the only proof-of-power shot we have.
- Title adds what the image can't. The current title already says "$600", so either (a) keep it in the title and put "BEFORE / AFTER" (or no text) on the image, or (b) put "$600" big on the image and let the title carry the state change (Luke Peavy's 25x pairs "$4,000" in the image with a no-number title). Pick one; don't print "$600" in both.
- **Yes, a new photo of him is needed.** Every golf-cart outlier with a face uses a clean, posed full-body shot of the creator standing with the cart (Luke Peavy x3, Spicer). Build footage rarely gives a sharp, well-lit, eyes-to-camera still. Shoot 10 minutes at golden hour: (a) him standing beside the finished cart, key in hand, from the same angle as the best existing "before" frame, so he can be composited in the center of a split; (b) one natural reaction close-up (surprise/pride, not shock-face) as an A/B variant. The "before" half must come from existing footage because the cart is already restored, so match that frame's angle and lens height.

---

## 8. Applying it to the golf cart

Facts on record: 2012 Yamaha G29 (Drive), electric, bought for **$600**, **wouldn't turn on**: **no batteries, no solenoid, dead controller**; **sun-faded plastic**; he **buffed the body instead of repainting**; restored black trim, painted frame, new battery, LED lights, rims, diamond-stitch seat; **golden-hour reveal**; **tail lights glowing = proof of power**. Not on record: driving shot, total spend, resale value. Current retention: 85% gone by 0:30.

The current problem is in the first 30 seconds, so the next script should beat the 66-69/80 bar the calibration videos set on the rubric.

### Fit 1: Cheap + Dead (Archetype A)
Leans on: "$600", "2012 Yamaha", "wouldn't even turn on", the three-item failure list (no batteries, no solenoid, dead controller; it maps exactly onto Luke Peavy's list rhythm), sun-faded plastic as the visual. Payoff to plant: the moment it powers on, proven by the tail lights. Corpus support: ChrisFix 4.33x, Luke Peavy 6.09x, 2vintage 6.88x, Ultimate Rebuilds 4.89x.

### Fit 2: Can I? (Archetype B, beginner stakes)
Leans on: he's a garage guy, not a golf-cart tech; the question "will it even turn on?" (not "will it drive", because there's no driving shot). Payoff: tail lights glowing at golden hour. Corpus support: Luke Peavy's golf-cart rebuild, 25.18x, the single biggest outlier in the golf-cart niche, uses exactly this with a beginner admission.

### Fit 3: Reveal-first with the buff-not-paint twist (Archetype C)
Leans on: the sun-faded before vs the golden-hour after, flashed by ~0:25, and the counterintuitive choice "I didn't repaint it" as the open loop (how did faded plastic come back without paint?). Corpus support: ChrisFix's faded-paint correction video (17.8M, 4.35x) proves faded-finish revival is itself a hook; Ultimate Rebuilds' golf cart (3.69x) shows the after by 0:27; Atlantic Beach's $600 cart (2.73x) uses "beginning to end".

### Not recommended yet
- **Cost Ledger (D):** one of the strongest in the corpus (Havesomevision 484x, Luke Peavy 7.87x), but we don't have the total spend or a resale value. If he can tally receipts and get one local price for a comparable G29, this becomes available and should be reconsidered.
- **Ticking clock (G):** no real deadline on record.
- **Cold open (H):** needs a strong live-audio moment; with TTS VO first, it would sound fake.
- **Any promise to drive it:** no driving footage; Rule 6 says only promise what's shown.

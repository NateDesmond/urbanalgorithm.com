# Intro scripts v2 (price anchor + it drives). For review, not yet rendered.
# Facts added: new Yamaha Drive2 MSRP $9,952 (2026); it DRIVES on camera (517-534, backs up + pulls forward in garage, brake lights);
# floor mat kept + restored (411-420). Mock assumptions per Nate: solenoid + controller replaced; total spend $1,000.

## 1 · The Bet
0.0  This tail light is going to tell me if I wasted six hundred bucks... | 127-133 old tail light, unlit | $600 tag
3.2  or got a ten thousand dollar golf cart for almost nothing. | 560-562 finished cart, street | flash; NEW ≈ $10,000 tag
6.4  Because the day I got it, nothing on it lit up. | 0.4-3 beat-up cart | DEAD stamp
9.0  2012 Yamaha. Empty battery bay. No solenoid. Controller's not working. | 6-9 bay / 17-19 / 12-14 | checkboxes
13.0 Sun-faded lights, a chalky body, gray trim. | 21-23 / 44-46 / 332-334 | BODY
15.4 I'm buffing the body, not painting it. | 250-254 | NO REPAINT stamp
17.4 So here's the bet. If those tail lights glow and this thing drives, I win. | 503-506 bay / 517-519 cart, lights off | MAKE IT DRIVE
21.6 If not, I just built a very clean six hundred dollar lawn ornament. | 571.5-574 golden hour, front | STEP 1

## 2 · The List
0.0  Six hundred dollar golf cart. 2012 Yamaha. Won't turn on. | 0.4-3 beat-up | $600 tag + DEAD
2.8  New, these are about ten grand. | 571.5-573 golden hour flash | NEW ≈ $10,000
4.4  So either I got a steal, or there's a reason it was six hundred. | 48-51 walkaround |
7.6  Here's the reason. Batteries. There aren't any. | 6-9 bay | ☐ BATTERIES
9.8  Solenoid. Also missing. Controller. Dead. | 17-19 / 12-14 | ☐ SOLENOID ☐ CONTROLLER
11.8 Plus a couple of broken wires I'm not counting as a box. | 138-141 wiring nest |
14.6 Body. Oxidized, chipped, sun-faded. I'm buffing it, not repainting it. | 31-35 / 250-256 | ☐ BODY, NO REPAINT
18.6 Four boxes I can probably handle. It's the last one I'm not sure about. | 142-146 / 503-506 | ☐ MAKE IT DRIVE (orange)
22.6 Will this thing ever move again? | 560-562 finished, street | punch-in, then STEP 1

## 3 · From This
0.0  I turned a six hundred dollar golf cart into this. | 571.5-574 golden hour, front | $600 tag, flash
2.4  New, one of these is about ten grand. | 574-575 | NEW ≈ $10,000
4.2  Here's what six hundred bucks actually got me. A 2012 Yamaha that wouldn't even turn on. | 0.4-3 / 6-10 bay | split; DEAD
8.6  No batteries. No solenoid. Dead controller. | 12-15 | ☐ ☐ ☐
10.6 And the plastic looks like it's been in an oven. | 44-46 / 21-23 | ☐ BODY
13.0 A body shop would paint it. I'm not a body shop. So the body just got a buffer. | 31-35 / 250-254 | NO REPAINT
17.4 Even this gray trim came back black without paint. | 338-343 |
19.8 But none of that matters if it won't drive. | 503-508 bay |
22.0 Best case, it drives. Worst case, I spent six hundred bucks on a really shiny chair. | 517-519 cart, lights off | ☐ MAKE IT DRIVE, STEP 1
